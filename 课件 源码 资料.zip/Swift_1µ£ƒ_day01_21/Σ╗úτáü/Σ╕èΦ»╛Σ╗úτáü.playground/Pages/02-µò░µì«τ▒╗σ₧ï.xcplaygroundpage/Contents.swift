//var num = 10
//num += 20
//num += 30
//let age = num
//print(age)

//func getAge() -> Int {
//    return 10
//}
//let age = getAge()
//print(age)

var age: Int = 10
print(Int16.min)
var num = 10

let error = (404, "Not Found")
error.0
error.1
